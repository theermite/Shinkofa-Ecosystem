import { useState } from "react";
import { COLORS } from "./utils/constants";

function App() {
  const [step, setStep] = useState(1); // 1: Upload, 2: Config, 3: Export
  const [audioFile, setAudioFile] = useState(null);

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center p-4"
      style={{ backgroundColor: COLORS.cremeBlanc }}
    >
      {/* Header */}
      <header className="mb-8 text-center">
        <h1
          className="text-4xl font-bold mb-2"
          style={{ color: COLORS.bleuProfond }}
        >
          🎙️ Podcast The Ermite
        </h1>
        <p className="text-lg" style={{ color: COLORS.bleuRoyal }}>
          Enrichis ton audio avec fréquences & transcripts
        </p>
      </header>

      {/* Progress Steps */}
      <div className="flex gap-4 mb-8">
        {[1, 2, 3].map((num) => (
          <div
            key={num}
            className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold"
            style={{
              backgroundColor:
                step >= num ? COLORS.vertEmeraude : COLORS.bleuClair,
              opacity: step >= num ? 1 : 0.5,
            }}
          >
            {num}
          </div>
        ))}
      </div>

      {/* Main Content */}
      <div
        className="w-full max-w-2xl p-8 rounded-lg shadow-lg"
        style={{ backgroundColor: "white" }}
      >
        {step === 1 && (
          <div className="text-center">
            <h2
              className="text-2xl font-bold mb-4"
              style={{ color: COLORS.bleuProfond }}
            >
              1. Upload ton audio
            </h2>
            <input
              type="file"
              accept="audio/*"
              onChange={(e) => {
                setAudioFile(e.target.files[0]);
                setStep(2);
              }}
              className="hidden"
              id="audio-upload"
            />
            <label
              htmlFor="audio-upload"
              className="inline-block px-8 py-4 rounded-lg text-white font-bold cursor-pointer text-xl"
              style={{ backgroundColor: COLORS.bleuRoyal }}
            >
              📁 Choisir fichier audio
            </label>
          </div>
        )}

        {step === 2 && (
          <div>
            <h2
              className="text-2xl font-bold mb-4"
              style={{ color: COLORS.bleuProfond }}
            >
              2. Configuration
            </h2>
            <p className="mb-4">
              Fichier : <strong>{audioFile?.name}</strong>
            </p>
            <p style={{ color: COLORS.jauneMoutarde }}>
              🚧 Phase 2 : Choix fonds & vidéo (à venir)
            </p>
            <button
              onClick={() => setStep(3)}
              className="mt-6 px-6 py-3 rounded-lg text-white font-bold"
              style={{ backgroundColor: COLORS.vertEmeraude }}
            >
              Suivant →
            </button>
          </div>
        )}

        {step === 3 && (
          <div className="text-center">
            <h2
              className="text-2xl font-bold mb-4"
              style={{ color: COLORS.bleuProfond }}
            >
              3. Export
            </h2>
            <p style={{ color: COLORS.jauneMoutarde }}>
              🚧 Phase 3 : Export MP3 & vidéo (à venir)
            </p>
            <button
              onClick={() => {
                setStep(1);
                setAudioFile(null);
              }}
              className="mt-6 px-6 py-3 rounded-lg text-white font-bold"
              style={{ backgroundColor: COLORS.bleuRoyal }}
            >
              ← Recommencer
            </button>
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="mt-8 text-sm" style={{ color: COLORS.bleuRoyal }}>
        v1.0.0 - Phase 1 Config Base ✅
      </footer>
    </div>
  );
}

export default App;
