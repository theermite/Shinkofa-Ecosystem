// Couleurs The Ermite
export const COLORS = {
  bleuProfond: "#192040",
  bleuRoyal: "#0c2284",
  bleuClair: "#0bb1f9",
  cremeBlanc: "#eaeaeb",
  vertEmeraude: "#008080",
  jauneMoutarde: "#d4a044",
  rougeBordeaux: "#800020",
};

// Fréquences disponibles (Hz)
export const FREQUENCIES = {
  HZ_432: { name: "432Hz (Calme)", value: 432 },
  HZ_528: { name: "528Hz (Réparation)", value: 528 },
  BINAURAL_4HZ: { name: "Binaurale 4Hz (Sommeil)", base: 200, offset: 4 },
  BINAURAL_8HZ: { name: "Binaurale 8Hz (Relaxation)", base: 200, offset: 8 },
  BINAURAL_10HZ: { name: "Binaurale 10Hz (Créativité)", base: 200, offset: 10 },
};

// Musiques Creative Commons (placeholder - Phase 2)
export const MUSIC_LIBRARY = [
  { id: 1, name: "Ambient Calm 1", url: "/music/ambient1.mp3" },
  { id: 2, name: "Lo-Fi Focus", url: "/music/lofi1.mp3" },
  { id: 3, name: "Meditation Flow", url: "/music/meditation1.mp3" },
  { id: 4, name: "Nature Sounds", url: "/music/nature1.mp3" },
  { id: 5, name: "Gentle Piano", url: "/music/piano1.mp3" },
];

// Styles vidéo
export const VIDEO_STYLES = {
  STAR_WARS: "starwars",
  TYPEWRITER: "typewriter",
};
